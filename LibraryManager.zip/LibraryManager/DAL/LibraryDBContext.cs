﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using LibraryManager.Models;
using System.Text.RegularExpressions;

namespace LibraryManager.DAL
{
    public class LibraryDBContext : DbContext
    {
        public LibraryDBContext(DbContextOptions<LibraryDBContext> options)
        : base(options)
        {
            if (Database.EnsureCreated() && Libraries?.Count() == 0)
            {
                Seed();
            }
        }
        private void Seed()
        {
            Library library = new Library
            {
                Genre = "Mishna",

            };
            Libraries.Add(library);
            SaveChanges();
        }

        public DbSet<Library> Libraries { get; set; }
        public DbSet<Shelf> Shelves { get; set; }
        public DbSet<Book> Books { get; set; }

    }
}
