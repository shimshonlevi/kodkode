﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using LibraryManager.Models;
using LibraryManager.DAL;

namespace LibraryManager.Controllers
{
    public class ShelfController : Controller
    {
        private readonly LibraryDBContext _libraryDBC;

        public ShelfController(LibraryDBContext libraryDBC)
        {
            _libraryDBC = libraryDBC;
        }
        public IActionResult ListS()
        {
            var shelves = _libraryDBC.Shelves.ToList();
            return View(shelves);
        }

        public IActionResult CreateS()
        {
            return View();
        }

        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult CreateS(Shelf shelf)
        {
            if (shelf == null) return RedirectToAction("ListS");
            _libraryDBC.Shelves.Add(shelf);
            _libraryDBC.SaveChanges();
            return RedirectToAction("ListS");
        }
    }
}
