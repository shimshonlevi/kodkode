﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using LibraryManager.Models;
using LibraryManager.DAL;

namespace LibraryManager.Controllers
{
    public class LibraryController : Controller
    {
        private readonly LibraryDBContext _libraryDBC;

        public LibraryController(LibraryDBContext libraryDBC)
        {
            _libraryDBC = libraryDBC;
        }

        public IActionResult ListL()
        {
            return View(_libraryDBC.Libraries.ToList());
        }

        public IActionResult CreateL()
        {
            return View();
        }

        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult CreateL(Library library)
        {
            if (library == null) return RedirectToAction("ListL");
            _libraryDBC.Libraries.Add(library);
            _libraryDBC.SaveChanges();
            return RedirectToAction("ListL");
        }

        public IActionResult ShelvesInLibrary(int id)
        {
            var library = _libraryDBC.Libraries.Include(l => l.Shelves).FirstOrDefault(l => l.Id == id);
            if (library == null)
            {
                return NotFound();
            }

            var availableShelves = _libraryDBC.Shelves.Where(s => s.LibraryId == null).ToList();
            ViewBag.Shelves = availableShelves;
            return View(library);
        }

        [HttpPost]
        public IActionResult AddShelvesToLibrary(int libraryId, List<int> shelfIds)
        {
            var library = _libraryDBC.Libraries.Include(l => l.Shelves).FirstOrDefault(l => l.Id == libraryId);
            if (library == null)
            {
                return NotFound();
            }


            foreach (var shelfId in shelfIds)
            {
                var shelf = _libraryDBC.Shelves.FirstOrDefault(s => s.Id == shelfId);
                if (shelf != null && shelf.LibraryId == null)
                {
                    shelf.LibraryId = libraryId;
                    library.Shelves.Add(shelf);
                }
                
            }

            _libraryDBC.SaveChanges();
            return RedirectToAction("ShelvesInLibrary", new { id = libraryId });
        }
    }
}


