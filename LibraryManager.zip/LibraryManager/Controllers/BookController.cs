﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using LibraryManager.Models;
using LibraryManager.DAL;

namespace LibraryManager.Controllers
{
    public class BookController : Controller
    {
        private readonly LibraryDBContext _libraryDBC;

        public BookController(LibraryDBContext libraryDBC)
        {
            _libraryDBC = libraryDBC;
        }

        public IActionResult ListB()
        {
            return View(_libraryDBC.Books.ToList());
        }

        public IActionResult CreateB()
        {
            var genres = _libraryDBC.Libraries.Select(l => l.Genre).Distinct().ToList();
            ViewBag.Genres = genres;
            return View();
        }

        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult CreateB(Book book)
        {
            if (book == null) return RedirectToAction("ListB");
            _libraryDBC.Books.Add(book);
            _libraryDBC.SaveChanges();
            return RedirectToAction("ListB");
        }
        [HttpGet]
        public IActionResult AddToLibrary(int id)
        {
            var book = _libraryDBC.Books.Find(id);
            if (book == null)
            {
                return NotFound();
            }

            var library = _libraryDBC.Libraries.Include(l => l.Shelves).FirstOrDefault(l => l.Genre == book.Genre);

            if (library == null)
            {
                return NotFound();
            }

            var suitableShelves = library.Shelves.Where(s => s.Height >= book.Height + 2).ToList();
            ViewBag.SuitableShelves = suitableShelves;
            return View(book);
        }

        [HttpPost]
public IActionResult AddToLibrary(int bookId, int shelfId)
{
    var book = _libraryDBC.Books.Find(bookId);
    if (book == null)
    {
        return NotFound();
    }

    var shelf = _libraryDBC.Shelves.Include(s => s.Books).FirstOrDefault(s => s.Id == shelfId);
    if (shelf == null)
    {
        TempData["ErrorMessage"] = "The selected shelf does not exist.";
        return RedirectToAction("AddToLibrary", new { id = bookId });
    }

    if (book.Height > (shelf.Height - 2))
    {
        TempData["ErrorMessage"] = "The selected shelf does not fit.";
        return RedirectToAction("AddToLibrary", new { id = bookId });
    }

    if (shelf.Books == null)
    {
        shelf.Books = new List<Book>();
    }

    shelf.Books.Add(book);
    _libraryDBC.SaveChanges();

    return RedirectToAction("AddToLibrary", new { id = bookId });
}
    }
}
