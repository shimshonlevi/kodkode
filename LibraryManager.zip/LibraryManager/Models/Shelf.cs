﻿using Newtonsoft.Json.Linq;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.InteropServices;

namespace LibraryManager.Models
{
    public class Shelf
    {
        [Key]
        public int Id { get; set; }
        public float Height { get; set; }
        public float Width { get; } = 80;
        public int? LibraryId { get; set; }
        public Library library { get; set; }
        public List<Book> Books { get; set; }
    }
}
