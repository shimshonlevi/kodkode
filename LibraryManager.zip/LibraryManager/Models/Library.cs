﻿using Newtonsoft.Json.Linq;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.InteropServices;

namespace LibraryManager.Models
{
    public class Library
    {
        [Key]
        public int Id { get; set; }
        public string Genre { get; set; }
        public List<Shelf> Shelves { get; set; }
    }
}
